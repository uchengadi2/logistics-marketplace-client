self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0929c5316af0426603c3c8c6ef497e53",
    "url": "/index.html"
  },
  {
    "revision": "81b2a54fa9ad3bf02260",
    "url": "/static/css/main.8a8db68b.chunk.css"
  },
  {
    "revision": "83c6fe2f4e4444ee2165",
    "url": "/static/js/2.649265ab.chunk.js"
  },
  {
    "revision": "81b2a54fa9ad3bf02260",
    "url": "/static/js/main.60430cfc.chunk.js"
  },
  {
    "revision": "56256c405bfa76082cb3",
    "url": "/static/js/runtime~main.ea895c90.js"
  },
  {
    "revision": "76baf4069a220dadc0eb2573710e20d5",
    "url": "/static/media/cover_image_1.76baf406.png"
  },
  {
    "revision": "9730290748805164acce0ccdd96d1529",
    "url": "/static/media/logo.97302907.svg"
  }
]);